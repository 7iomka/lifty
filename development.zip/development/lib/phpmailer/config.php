<?php
$__smtp = array(
    "host" => "smtp.yandex.ru", //smtp сервер
    "debug" => 0,                   //отображение информации дебаггера (0 - нет вообще)
    "auth" => true,                 //сервер требует авторизации
    "port" => 465,                    //порт (по-умолчанию - 25)
    "secure" => "ssl",
    "from_name" => "SEOSINTEZ",
		"username" => "xzyacheng-sender",//имя пользователя на сервере
    "password" => "xzyacheng-sender2015",//пароль
    "addreply" => "xzyacheng-sender@yandex.ru",//ваш е-mail
    "replyto" => "7iomka@gmail.com"      //e-mail ответа
 );
?>
