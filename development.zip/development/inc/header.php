<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Поставка, монтаж и замена лифтов. Сервис. Проектирование лифтов и шахт.</title>
    <meta name="keywords" content="Щербинский лифтостроительный завод ЩЛЗ лифты пассажирские лифты грузовые лифты больничные подъемник">
    <meta name="description" content="один из основных производителей лифтового оборудования изготавливает наиболее широкую в России и за ее пределами гамму лифтов и подъемников с электрическим и гидравлическим приводом">
    <!-- <meta name=viewport content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta content="yes" name="apple-mobile-web-app-capable">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent"> -->
    <!-- Favicons -->
    <!-- <link rel="shortcut icon" sizes="16x16 24x24 32x32 48x48 64x64" href="/favicon.ico"> -->
    <link rel="icon" type="image/png" href="img/favicon.png" />
    <link rel="stylesheet" href="css/main.css" media="all" title="no title" charset="utf-8">

</head>
