<div id="header-nav">
      <!-- Small screen menu button -->

       <!-- <div id="hamburger-icon" class="hamburger">
          <div class="icon"></div>
          <div class="hamburger-text">Меню</div>
      </div>
      <div class="small-logo">
        <a href="#home" class="small-logo-link">
          <span class="logo__title">
              <span class="brown">seo</span>sintez.<span class="brown">ru</span>
          </span>
        </a>
      </div> -->

      <!-- /Small screen menu button -->

      <!-- Menu Items -->
      <nav id="menu" role="navigation">
        <ul>
          <li class="menu__item"><a href="/">Поставка лифтов</a></li>
          <li class="menu__item"><a href="servisnoe_obsluzhivanie">Сервисное обслуживание</a></li>
          <li class="menu__item"><a href="proektirovanie_liftov_i_shaht">Проектирование лифтов и шахт</a></li>
          <li class="menu__item"><a href="montazh_i_zamena_liftov">Монтаж и замена лифтов</a></li>
          <li class="menu__item menu__item--last"><a href="kontakty">Контакты</a></li>
        </ul>
      </nav>
    <!-- /Menu Items -->
</div>
